# FPS Converter Maker 3D — visor corregido

Este proyecto conserva el convertidor Android original. La corrección principal está en el reproductor incluido en:

`android/template/src/main/assets/player/index.html`

Se añadieron iluminación automática según el cielo de cada nivel, un botón para alternar entre Auto/Día/Noche, sombras aproximadas para bloques, paredes, modelos y enemigos, y atenuación bajo techos. Los sprites planos conservan una iluminación sencilla. También se mantienen las correcciones de rotación de modelos, colisiones, lectura de niveles, tipos desconocidos y acciones de juego.

## Compilación con GitHub Actions

El ZIP original no trae `template.apk` ni `llave.p12`, pero el flujo de GitHub Actions compartido por el usuario los genera al compilar. Para que ese flujo lo encuentre, el ZIP subido al repositorio debe llamarse `convertidor.zip` y tener la carpeta `android/` directamente en su raíz.

Si se compila fuera de ese flujo, hay que generar esos recursos antes de compilar el convertidor. La llave creada de nuevo en cada ejecución firma los juegos con certificados distintos; para permitir actualizaciones sobre instalaciones previas, hay que reutilizar una llave estable y privada.

Este paquete contiene código fuente; no incluye un APK compilado.
