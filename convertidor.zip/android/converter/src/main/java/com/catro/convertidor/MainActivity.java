package com.catro.convertidor;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Pantalla única: eliges el juego, escribes el nombre, (opcional) logotipo y ruta de datos,
 * y al tocar "Generar APK" eliges dónde guardarlo.
 */
public class MainActivity extends Activity {

    private static final int RQ_GAME = 1, RQ_LOGO = 2, RQ_SAVE = 3;

    private final Handler ui = new Handler(Looper.getMainLooper());

    private Uri gameUri, logoUri, outUri;
    private String gameName = "", gameExt = "zip";
    private Bitmap logoBmp;

    private TextView tvGame, tvStatus;
    private EditText etName, etData;
    private ImageView ivLogo;
    private Button btnGen, btnInstall;
    private ProgressBar pb;

    // ------------------------------------------------------------------ interfaz
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(String text, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(bold ? 16 : 13);
        t.setTextColor(bold ? Color.BLACK : 0xFF555555);
        if (bold) t.setPadding(0, dp(16), 0, dp(4));
        else t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        return e;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(24), dp(18), dp(40));
        sv.addView(col);
        sv.setFillViewport(true);
        setContentView(sv);

        TextView title = new TextView(this);
        title.setText("Generador de juegos");
        title.setTextSize(24);
        title.setTextColor(Color.BLACK);
        col.addView(title);
        col.addView(label("Convierte un juego de FPS Maker 3D en un APK que se instala solo. Todo ocurre en tu teléfono.", false));

        col.addView(label("1. Archivo del juego (.zip o .pck)", true));
        col.addView(button("Elegir archivo del juego", v -> pick(RQ_GAME, "*/*")));
        tvGame = label("Ningún archivo elegido", false);
        col.addView(tvGame);

        col.addView(label("2. Nombre del juego", true));
        etName = edit("Ej. The presence: Slender Man");
        col.addView(etName);

        col.addView(label("3. Logotipo (opcional)", true));
        col.addView(button("Elegir imagen", v -> pick(RQ_LOGO, "image/*")));
        ivLogo = new ImageView(this);
        ivLogo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(84), dp(84));
        lp.topMargin = dp(8);
        ivLogo.setLayoutParams(lp);
        ivLogo.setVisibility(View.GONE);
        col.addView(ivLogo);
        col.addView(label("Se recorta cuadrado al centro. Sin imagen, el icono lleva la inicial del nombre.", false));

        col.addView(label("4. Ruta de datos del juego (opcional)", true));
        etData = edit("Vacío = el juego va dentro del APK");
        col.addView(etData);
        col.addView(label("Si escribes una carpeta (ej. juego), el APK no lleva el juego dentro: lo busca en Android/data/<app>/files/<carpeta>/ y ahí debes copiar game.zip o game.pck. Útil para juegos muy pesados.", false));

        btnGen = button("Generar APK", v -> generate());
        btnGen.setTextSize(18);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        gp.topMargin = dp(24);
        btnGen.setLayoutParams(gp);
        col.addView(btnGen);

        pb = new ProgressBar(this);
        pb.setIndeterminate(true);
        pb.setVisibility(View.GONE);
        pb.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        col.addView(pb);

        tvStatus = label("", false);
        tvStatus.setTextSize(14);
        col.addView(tvStatus);

        btnInstall = button("Instalar el APK generado", v -> install());
        btnInstall.setVisibility(View.GONE);
        col.addView(btnInstall);
    }

    // ------------------------------------------------------------------ selección de archivos
    private void pick(int rq, String mime) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        startActivityForResult(i, rq);
    }

    private String displayName(Uri u) {
        String name = null;
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ix >= 0) name = c.getString(ix);
            }
        } catch (Exception ignored) {
        }
        if (name == null) name = u.getLastPathSegment() == null ? "archivo" : u.getLastPathSegment();
        return name;
    }

    private long fileSize(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.SIZE);
                if (ix >= 0 && !c.isNull(ix)) return c.getLong(ix);
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

    @Override
    protected void onActivityResult(int rq, int res, Intent data) {
        super.onActivityResult(rq, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();

        if (rq == RQ_GAME) {
            gameUri = u;
            gameName = displayName(u);
            gameExt = gameName.toLowerCase().endsWith(".pck") ? "pck" : "zip";
            long sz = fileSize(u);
            tvGame.setText("Juego: " + gameName + (sz >= 0 ? String.format(" (%.1f MB)", sz / 1048576.0) : ""));
            new Thread(() -> inspectGame(u)).start();
        } else if (rq == RQ_LOGO) {
            logoUri = u;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeStream(in, null, o);
                int s = 1;
                while (Math.max(o.outWidth, o.outHeight) / s > 1024) s *= 2;
                try (InputStream in2 = getContentResolver().openInputStream(u)) {
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = s;
                    logoBmp = BitmapFactory.decodeStream(in2, null, o2);
                }
                if (logoBmp != null) {
                    ivLogo.setImageBitmap(logoBmp);
                    ivLogo.setVisibility(View.VISIBLE);
                } else {
                    status("No pude leer esa imagen.");
                }
            } catch (Exception e) {
                status("No pude leer esa imagen: " + e.getMessage());
            }
        } else if (rq == RQ_SAVE) {
            outUri = u;
            runBuild();
        }
    }

    /** Mira dentro del zip: confirma que parece un proyecto y toma el título para proponer el nombre. */
    private void inspectGame(Uri u) {
        String title = null;
        boolean hasPck = gameExt.equals("pck");
        if (!hasPck) {
            try (ZipInputStream z = new ZipInputStream(getContentResolver().openInputStream(u))) {
                ZipEntry e;
                while ((e = z.getNextEntry()) != null) {
                    String n = e.getName().toLowerCase();
                    if (n.endsWith(".pck")) hasPck = true;
                    if (n.endsWith(".gcg") && title == null) {
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] buf = new byte[512];
                        int k;
                        while ((k = z.read(buf)) > 0 && bo.size() < 512) bo.write(buf, 0, k);
                        title = new String(bo.toByteArray(), "ISO-8859-1").split("\\r?\\n")[0].trim();
                    }
                }
            } catch (Exception ignored) {
            }
        }
        final String t = title;
        final boolean ok = hasPck;
        ui.post(() -> {
            if (!ok) tvGame.setText(tvGame.getText() + "\n⚠ No encontré un .pck dentro: puede que no sea un proyecto de FPS Maker 3D.");
            if (t != null && !t.isEmpty() && etName.getText().toString().trim().isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (String w : t.toLowerCase().split(" ")) {
                    if (w.isEmpty()) continue;
                    sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(' ');
                }
                etName.setText(sb.toString().trim());
            }
        });
    }

    // ------------------------------------------------------------------ generar
    private String dataPath() {
        return etData.getText().toString().trim().replaceAll("^[/\\\\]+|[/\\\\]+$", "");
    }

    private void generate() {
        String name = etName.getText().toString().trim();
        String dp = dataPath();
        if (name.isEmpty()) { status("Escribe el nombre del juego."); return; }
        if (gameUri == null) { status("Elige primero el archivo del juego."); return; }
        if (dp.contains("..") || dp.matches(".*[:*?\"<>|].*")) { status("La ruta de datos tiene caracteres no permitidos."); return; }

        String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_TITLE, safe + ".apk");
        startActivityForResult(i, RQ_SAVE); // aquí eliges la carpeta donde se guarda
    }

    private void status(String s) {
        ui.post(() -> tvStatus.setText(s));
    }

    private void busy(boolean on) {
        ui.post(() -> {
            pb.setVisibility(on ? View.VISIBLE : View.GONE);
            btnGen.setEnabled(!on);
            if (on) btnInstall.setVisibility(View.GONE);
        });
    }

    private void runBuild() {
        final String name = etName.getText().toString().trim();
        final String dp = dataPath();
        final Uri target = outUri, game = gameUri;
        final String ext = gameExt;
        busy(true);
        status("Preparando…");

        new Thread(() -> {
            try {
                // plantilla (APK del reproductor) copiada a un archivo temporal
                File tpl = new File(getCacheDir(), "plantilla.apk");
                try (InputStream in = getAssets().open("template.apk"); OutputStream o = new FileOutputStream(tpl)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                }

                // llave de firma incluida en la app
                KeyStore ks = KeyStore.getInstance("PKCS12");
                try (InputStream in = getAssets().open("llave.p12")) {
                    ks.load(in, "generador".toCharArray());
                }
                String alias = ks.aliases().nextElement();
                PrivateKey key = (PrivateKey) ks.getKey(alias, "generador".toCharArray());
                X509Certificate cert = (X509Certificate) ks.getCertificate(alias);

                ApkBuilder.Params p = new ApkBuilder.Params();
                p.label = name;
                p.dataPath = dp;
                p.gameExt = ext;
                p.game = () -> getContentResolver().openInputStream(game);
                p.icons = this::makeIcon;

                try (OutputStream os = new BufferedOutputStream(getContentResolver().openOutputStream(target, "wt"), 1 << 16)) {
                    ApkBuilder.build(tpl, os, p, key, cert, this::status);
                }

                String id = ApkBuilder.makeAppId(name);
                String extra = dp.isEmpty() ? ""
                        : "\n\nEl juego NO va dentro. Copia game." + ext + " a:\nAndroid/data/" + id + "/files/" + dp + "/";
                status("¡Listo! El APK se guardó donde elegiste.\nIdentificador: " + id + extra);
                ui.post(() -> btnInstall.setVisibility(View.VISIBLE));
            } catch (Throwable t) {
                StringBuilder sb = new StringBuilder("No se pudo generar:\n" + t);
                StackTraceElement[] st = t.getStackTrace();
                for (int k = 0; k < Math.min(4, st.length); k++) sb.append("\n  ").append(st[k]);
                status(sb.toString());
            } finally {
                busy(false);
            }
        }).start();
    }

    private void install() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(outUri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            status("No pude abrir el instalador desde aquí. Abre el archivo .apk desde la app Archivos para instalarlo.");
        }
    }

    // ------------------------------------------------------------------ iconos
    private byte[] makeIcon(int size, boolean round) throws IOException {
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        Bitmap src = logoBmp;
        if (src == null) {
            p.setColor(0xFF22262E);
            c.drawRect(0, 0, size, size, p);
            p.setColor(0xFFF0F0F0);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(size * 0.6f);
            String n = etName.getText().toString().trim();
            String letter = n.isEmpty() ? "J" : n.substring(0, 1).toUpperCase();
            c.drawText(letter, size / 2f, size / 2f - (p.descent() + p.ascent()) / 2f, p);
        } else {
            int w = src.getWidth(), h = src.getHeight(), m = Math.min(w, h);
            Rect from = new Rect((w - m) / 2, (h - m) / 2, (w - m) / 2 + m, (h - m) / 2 + m);
            c.drawBitmap(src, from, new Rect(0, 0, size, size), p);
        }
        if (round) {
            Bitmap r = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas rc = new Canvas(r);
            Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG);
            rc.drawCircle(size / 2f, size / 2f, size / 2f, mp);
            mp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            rc.drawBitmap(out, 0, 0, mp);
            out = r;
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        out.compress(Bitmap.CompressFormat.PNG, 100, bo);
        return bo.toByteArray();
    }
}
