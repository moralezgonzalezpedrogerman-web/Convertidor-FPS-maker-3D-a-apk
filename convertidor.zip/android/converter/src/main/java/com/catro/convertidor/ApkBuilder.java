package com.catro.convertidor;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Enumeration;
import java.util.List;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Convierte la plantilla del reproductor (un APK ya compilado) en el APK de un juego concreto:
 * cambia el nombre y el identificador, los iconos, añade el juego y vuelve a firmar (firma v1).
 * Es Java puro (sin clases de Android) para poder probarlo también en un ordenador.
 */
public final class ApkBuilder {

    /** Textos de relleno que la plantilla lleva en su manifiesto; deben coincidir con template/. */
    public static final String PH_PKG = "com.catro.appXXXXXXXXXXXX";                  // 25 caracteres
    public static final String PH_LABEL = "LBLPLACEHOLDER__________________________________"; // 48 caracteres

    public interface GameSource { InputStream open() throws IOException; }
    public interface IconProvider { byte[] png(int size, boolean round) throws IOException; }
    public interface Progress { void say(String msg); }

    public static final class Params {
        public String label;        // nombre que verá el usuario
        public String dataPath = ""; // carpeta de datos del teléfono (vacío = juego dentro del APK)
        public GameSource game;     // contenido de game.zip / game.pck (solo si dataPath está vacío)
        public String gameExt = "zip";
        public IconProvider icons;  // puede ser null: se deja el icono de la plantilla
    }

    private static final class Item { String name; byte[] sha; }

    // ------------------------------------------------------------------ utilidades
    public static String makeAppId(String name) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(name.trim().toLowerCase().getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder("com.catro.app");
        for (int i = 0; i < 6; i++) sb.append(String.format("%02x", h[i] & 255));
        return sb.toString(); // 13 + 12 = 25 caracteres, igual que PH_PKG
    }

    static String fit(String s, int n, boolean asciiOnly) {
        if (asciiOnly) {
            s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
            s = s.replaceAll("[^\\x20-\\x7E]", "");
        }
        if (s.length() > n) {
            s = s.substring(0, n);
            if (Character.isHighSurrogate(s.charAt(n - 1))) s = s.substring(0, n - 1) + " ";
        }
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < n) sb.append(' ');
        return sb.toString();
    }

    private static int replaceAll(byte[] data, byte[] from, byte[] to) {
        if (from.length != to.length) throw new IllegalArgumentException("longitudes distintas");
        int count = 0;
        outer:
        for (int i = 0; i <= data.length - from.length; i++) {
            for (int j = 0; j < from.length; j++) if (data[i + j] != from[j]) continue outer;
            System.arraycopy(to, 0, data, i, to.length);
            count++;
            i += from.length - 1;
        }
        return count;
    }

    /** Cambia un texto de relleno por otro de la misma longitud (UTF-16 y UTF-8). Devuelve cuántas veces. */
    static int patch(byte[] data, String from, String to) {
        int c = 0;
        c += replaceAll(data, from.getBytes(StandardCharsets.UTF_16LE), fit(to, from.length(), false).getBytes(StandardCharsets.UTF_16LE));
        c += replaceAll(data, from.getBytes(StandardCharsets.UTF_8), fit(to, from.length(), true).getBytes(StandardCharsets.UTF_8));
        return c;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[65536];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close();
        return o.toByteArray();
    }

    private static String b64(byte[] b) { return Base64.getEncoder().encodeToString(b); }

    private static byte[] sha256(byte[] b) throws Exception { return MessageDigest.getInstance("SHA-256").digest(b); }

    // ------------------------------------------------------------------ construcción
    public static void build(File template, OutputStream out, Params p, PrivateKey key, X509Certificate cert, Progress prog) throws Exception {
        final String appId = makeAppId(p.label);
        final Pattern iconRx = Pattern.compile("^res/mipmap[^/]*/[^/]*ic_launcher(_round)?\\.png$");
        List<Item> items = new ArrayList<>();
        ZipOutputStream zos = new ZipOutputStream(out);
        zos.setLevel(6);
        boolean patchedManifest = false;

        try (ZipFile zf = new ZipFile(template)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String name = e.getName();
                if (e.isDirectory()) continue;
                if (name.matches("^META-INF/[^/]*\\.(SF|RSA|DSA|EC)$") || name.equals("META-INF/MANIFEST.MF")) continue; // firma vieja
                if (name.startsWith("assets/player/game.")) continue;

                byte[] data = readAll(zf.getInputStream(e));
                boolean stored = e.getMethod() == ZipEntry.STORED;

                if (name.equals("AndroidManifest.xml")) {
                    int a = patch(data, PH_PKG, appId), b = patch(data, PH_LABEL, p.label);
                    if (a == 0 || b == 0) throw new IOException("La plantilla no tiene los textos de relleno esperados (id=" + a + ", nombre=" + b + ")");
                    patchedManifest = true;
                    prog.say("Nombre e identificador aplicados");
                } else if (name.equals("resources.arsc")) {
                    patch(data, PH_PKG, appId);
                } else if (name.equals("assets/player/config.json")) {
                    String json = "{\"name\":" + jsonStr(p.label) + ",\"dataPath\":" + jsonStr(p.dataPath) + "}";
                    data = json.getBytes(StandardCharsets.UTF_8);
                } else if (p.icons != null && iconRx.matcher(name).matches()) {
                    int size = name.contains("xxxhdpi") ? 192 : name.contains("xxhdpi") ? 144 : name.contains("xhdpi") ? 96
                            : name.contains("hdpi") ? 72 : 48;
                    data = p.icons.png(size, name.contains("_round"));
                }
                put(zos, items, name, data, stored);
            }
        }
        if (!patchedManifest) throw new IOException("La plantilla no trae AndroidManifest.xml");

        if (p.dataPath.isEmpty()) {
            if (p.game == null) throw new IOException("Falta el archivo del juego");
            prog.say("Guardando el juego dentro del APK…");
            putStream(zos, items, "assets/player/game." + p.gameExt, p.game);
        }

        prog.say("Firmando…");
        sign(zos, items, key, cert);
        zos.finish();
        zos.flush();
    }

    private static String jsonStr(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            if (c == '"' || c == '\\') sb.append('\\').append(c);
            else if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
            else sb.append(c);
        }
        return sb.append('"').toString();
    }

    private static void put(ZipOutputStream zos, List<Item> items, String name, byte[] data, boolean stored) throws Exception {
        ZipEntry e = new ZipEntry(name);
        if (stored) {
            CRC32 crc = new CRC32();
            crc.update(data);
            e.setMethod(ZipEntry.STORED);
            e.setSize(data.length);
            e.setCompressedSize(data.length);
            e.setCrc(crc.getValue());
        }
        e.setTime(978307200000L); // fecha fija: el resultado no cambia entre ejecuciones
        zos.putNextEntry(e);
        zos.write(data);
        zos.closeEntry();
        Item it = new Item();
        it.name = name;
        it.sha = sha256(data);
        items.add(it);
    }

    /** Para archivos grandes: dos pasadas (CRC y tamaño primero) y se guarda sin recomprimir. */
    private static void putStream(ZipOutputStream zos, List<Item> items, String name, GameSource src) throws Exception {
        CRC32 crc = new CRC32();
        long size = 0;
        byte[] buf = new byte[65536];
        try (InputStream in = src.open()) {
            int n;
            while ((n = in.read(buf)) > 0) { crc.update(buf, 0, n); size += n; }
        }
        ZipEntry e = new ZipEntry(name);
        e.setMethod(ZipEntry.STORED);
        e.setSize(size);
        e.setCompressedSize(size);
        e.setCrc(crc.getValue());
        e.setTime(978307200000L);
        zos.putNextEntry(e);
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = src.open()) {
            int n;
            while ((n = in.read(buf)) > 0) { zos.write(buf, 0, n); md.update(buf, 0, n); }
        }
        zos.closeEntry();
        Item it = new Item();
        it.name = name;
        it.sha = md.digest();
        items.add(it);
    }

    // ------------------------------------------------------------------ firma v1 (JAR)
    private static String wrap(String line) {
        StringBuilder sb = new StringBuilder();
        int max = 70;
        while (line.length() > max) {
            sb.append(line, 0, max).append("\r\n ");
            line = line.substring(max);
            max = 69;
        }
        return sb.append(line).append("\r\n").toString();
    }

    private static void sign(ZipOutputStream zos, List<Item> items, PrivateKey key, X509Certificate cert) throws Exception {
        StringBuilder mf = new StringBuilder("Manifest-Version: 1.0\r\nCreated-By: Generador de juegos\r\n\r\n");
        List<String> sections = new ArrayList<>();
        for (Item it : items) {
            String sec = wrap("Name: " + it.name) + "SHA-256-Digest: " + b64(it.sha) + "\r\n\r\n";
            sections.add(sec);
            mf.append(sec);
        }
        byte[] mfBytes = mf.toString().getBytes(StandardCharsets.UTF_8);

        StringBuilder sf = new StringBuilder("Signature-Version: 1.0\r\nCreated-By: Generador de juegos\r\n");
        sf.append("SHA-256-Digest-Manifest: ").append(b64(sha256(mfBytes))).append("\r\n\r\n");
        for (int i = 0; i < items.size(); i++) {
            sf.append(wrap("Name: " + items.get(i).name))
              .append("SHA-256-Digest: ").append(b64(sha256(sections.get(i).getBytes(StandardCharsets.UTF_8)))).append("\r\n\r\n");
        }
        byte[] sfBytes = sf.toString().getBytes(StandardCharsets.UTF_8);

        Signature sg = Signature.getInstance("SHA256withRSA");
        sg.initSign(key);
        sg.update(sfBytes);
        byte[] rsa = pkcs7(sg.sign(), cert);

        plain(zos, "META-INF/MANIFEST.MF", mfBytes);
        plain(zos, "META-INF/CERT.SF", sfBytes);
        plain(zos, "META-INF/CERT.RSA", rsa);
    }

    private static void plain(ZipOutputStream zos, String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setTime(978307200000L);
        zos.putNextEntry(e);
        zos.write(data);
        zos.closeEntry();
    }

    // --- DER mínimo para PKCS#7 SignedData ---
    private static byte[] cat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }

    private static byte[] der(int tag, byte[]... parts) {
        byte[] body = cat(parts);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int n = body.length;
        if (n < 128) o.write(n);
        else if (n < 256) { o.write(0x81); o.write(n); }
        else if (n < 65536) { o.write(0x82); o.write(n >> 8); o.write(n & 255); }
        else { o.write(0x83); o.write(n >> 16); o.write((n >> 8) & 255); o.write(n & 255); }
        o.write(body, 0, body.length);
        return o.toByteArray();
    }

    private static byte[] oid(String dotted) {
        String[] t = dotted.split("\\.");
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(Integer.parseInt(t[0]) * 40 + Integer.parseInt(t[1]));
        for (int i = 2; i < t.length; i++) {
            long v = Long.parseLong(t[i]);
            List<Integer> parts = new ArrayList<>();
            do { parts.add(0, (int) (v & 0x7F)); v >>= 7; } while (v > 0);
            for (int k = 0; k < parts.size(); k++) o.write(parts.get(k) | (k < parts.size() - 1 ? 0x80 : 0));
        }
        return der(0x06, o.toByteArray());
    }

    private static byte[] pkcs7(byte[] signature, X509Certificate cert) throws Exception {
        byte[] nul = new byte[]{0x05, 0x00};
        byte[] sha256 = der(0x30, oid("2.16.840.1.101.3.4.2.1"), nul);
        byte[] signerInfo = der(0x30,
                der(0x02, new byte[]{1}),
                der(0x30, cert.getIssuerX500Principal().getEncoded(), der(0x02, cert.getSerialNumber().toByteArray())),
                sha256,
                der(0x30, oid("1.2.840.113549.1.1.1"), nul),
                der(0x04, signature));
        byte[] signedData = der(0x30,
                der(0x02, new byte[]{1}),
                der(0x31, sha256),
                der(0x30, oid("1.2.840.113549.1.7.1")),
                der(0xA0, cert.getEncoded()),
                der(0x31, signerInfo));
        return der(0x30, oid("1.2.840.113549.1.7.2"), der(0xA0, signedData));
    }
}
