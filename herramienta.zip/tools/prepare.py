#!/usr/bin/env python3
"""Convierte un paquete-*.zip (hecho por el generador) en un proyecto de Android listo para compilar.

Uso (desde la raíz del repositorio):  python3 tool/tools/prepare.py paquete-mi-juego.zip
El paquete trae: config.json, icon.png (opcional) y game.zip / game.pck (salvo que el juego
se guarde en una carpeta de datos del teléfono).
"""
import json, os, re, shutil, sys, zipfile
from xml.sax.saxutils import escape
from PIL import Image, ImageDraw, ImageFont

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')          # carpeta "tool"
APP = os.path.join(BASE, 'android', 'app', 'src', 'main')


def fail(msg):
    print('ERROR: ' + msg)
    sys.exit(1)


def slug(text):
    s = re.sub(r'[^a-z0-9]+', '_', text.lower().encode('ascii', 'ignore').decode()).strip('_')
    return s or 'juego'


def android_string(text):
    t = escape(text).replace('\\', '\\\\').replace("'", "\\'").replace('"', '\\"')
    t = t.replace('\n', ' ')
    return '\\' + t if t[:1] in '@?' else t


def square_icon(img, size):
    img = img.convert('RGBA')
    w, h = img.size
    m = min(w, h)
    img = img.crop(((w - m) // 2, (h - m) // 2, (w - m) // 2 + m, (h - m) // 2 + m))
    return img.resize((size, size), Image.LANCZOS)


def default_icon(name):
    img = Image.new('RGBA', (512, 512), (30, 30, 36, 255))
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.load_default(size=300)
    except TypeError:
        font = ImageFont.load_default()
    d.text((256, 256), (name[:1] or 'J').upper(), fill=(240, 240, 240, 255), font=font, anchor='mm')
    return img


def main():
    if len(sys.argv) < 2:
        fail('Falta el nombre del paquete .zip')
    pkg = sys.argv[1]
    if not os.path.isfile(pkg):
        fail('No existe el paquete: ' + pkg)
    z = zipfile.ZipFile(pkg)
    names = z.namelist()
    if 'config.json' not in names:
        fail('El paquete no trae config.json (¿lo hiciste con el generador?)')
    cfg = json.loads(z.read('config.json').decode('utf-8'))

    name = (cfg.get('name') or 'Mi juego').strip()[:60] or 'Mi juego'
    app_id = (cfg.get('appId') or '').strip().lower()
    if not re.fullmatch(r'[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+', app_id):
        app_id = 'com.juego.' + slug(name)
        print('Aviso: identificador no válido, se usará ' + app_id)
    version = re.sub(r'[^0-9A-Za-z._-]', '', str(cfg.get('version') or '1.0')) or '1.0'
    apk_name = re.sub(r'[^\w\- .]', '_', (cfg.get('apkName') or name).strip())[:80].strip() or 'juego'
    data_path = (cfg.get('dataPath') or '').strip().strip('/\\')
    if '..' in data_path:
        fail('La carpeta de datos no puede contener ".."')

    # --- reproductor + configuración + juego ---
    assets = os.path.join(APP, 'assets', 'player')
    shutil.rmtree(os.path.join(APP, 'assets'), ignore_errors=True)
    os.makedirs(assets)
    shutil.copy(os.path.join(BASE, 'player', 'index.html'), os.path.join(assets, 'index.html'))
    with open(os.path.join(assets, 'config.json'), 'w', encoding='utf-8') as f:
        json.dump({'name': name, 'dataPath': data_path}, f, ensure_ascii=False)
    if data_path:
        print('El juego NO se incluye en el APK: se buscará en Android/data/%s/files/%s/' % (app_id, data_path))
    else:
        game = next((n for n in ('game.zip', 'game.pck') if n in names), None)
        if not game:
            fail('El paquete no trae game.zip ni game.pck y no se indicó carpeta de datos')
        with open(os.path.join(assets, game), 'wb') as f:
            f.write(z.read(game))
        print('Juego incluido: %s (%.1f MB)' % (game, os.path.getsize(os.path.join(assets, game)) / 1e6))

    # --- nombre de la app ---
    vals = os.path.join(APP, 'res', 'values')
    os.makedirs(vals, exist_ok=True)
    with open(os.path.join(vals, 'strings.xml'), 'w', encoding='utf-8') as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">%s</string>\n</resources>\n' % android_string(name))

    # --- iconos ---
    src = Image.open(__import__('io').BytesIO(z.read('icon.png'))) if 'icon.png' in names else default_icon(name)
    for folder, size in (('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)):
        d = os.path.join(APP, 'res', 'mipmap-' + folder)
        os.makedirs(d, exist_ok=True)
        ic = square_icon(src, size)
        ic.save(os.path.join(d, 'ic_launcher.png'))
        mask = Image.new('L', (size, size), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)
        rd = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        rd.paste(ic, (0, 0), mask)
        rd.save(os.path.join(d, 'ic_launcher_round.png'))

    # --- propiedades de Gradle (solo ASCII) ---
    gp = os.path.join(BASE, 'android', 'gradle.properties')
    lines = [l for l in open(gp, encoding='utf-8').read().splitlines() if not re.match(r'(appId|versionName|versionCode)=', l)]
    lines += ['appId=' + app_id, 'versionName=' + version, 'versionCode=' + str(int(cfg.get('versionCode') or 1))]
    open(gp, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    open(os.path.join(BASE, 'apkname.txt'), 'w', encoding='utf-8').write(apk_name)
    print('Listo: "%s"  id=%s  versión=%s  archivo=%s.apk' % (name, app_id, version, apk_name))


main()
